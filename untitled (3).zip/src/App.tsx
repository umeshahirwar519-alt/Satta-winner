import { useEffect, useMemo, useRef, useState } from 'react';
import {
  BAZAARS,
  getAutoNumberForSlot,
  getIstParts,
  getSecondsUntilNextDraw,
} from './data/bazaars';
import {
  ensureAutoResult,
  subscribeMonthResults,
  type BazaarResultDoc,
} from './services/resultsService';
import { Header } from './components/Header';
import { CountdownHero } from './components/CountdownHero';
import { LiveBazaarGrid } from './components/LiveBazaarGrid';
import { MonthlyChart } from './components/MonthlyChart';
import { PasswordModal } from './components/PasswordModal';
import { AdminDrawer } from './components/AdminDrawer';

export default function App() {
  const [ist, setIst] = useState(() => getIstParts(new Date()));
  const [selectedMonth, setSelectedMonth] = useState(
    () => getIstParts(new Date()).monthStr
  );
  const [todayMonthResults, setTodayMonthResults] = useState<BazaarResultDoc[]>([]);
  const [chartMonthResults, setChartMonthResults] = useState<BazaarResultDoc[]>([]);
  const [loadingToday, setLoadingToday] = useState(true);
  const [loadingChart, setLoadingChart] = useState(true);
  const [dbError, setDbError] = useState<string | null>(null);
  const [passwordOpen, setPasswordOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);

  const syncedAutoSlotsRef = useRef<Set<string>>(new Set());
  const tapTimestampsRef = useRef<number[]>([]);

  // Live 1-second tick for exact countdown in seconds
  useEffect(() => {
    const timer = window.setInterval(() => {
      setIst(getIstParts(new Date()));
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Triple-tap anywhere on the website (outside form/button controls) opens Admin password prompt
  useEffect(() => {
    function handleDocumentClick(e: MouseEvent) {
      if (passwordOpen || adminOpen) return;
      const target = e.target as HTMLElement | null;
      if (target && target.closest('button, input, select, textarea, label')) {
        return;
      }
      const now = Date.now();
      const recent = tapTimestampsRef.current.filter((t) => now - t < 750);
      recent.push(now);
      if (recent.length >= 3) {
        tapTimestampsRef.current = [];
        setPasswordOpen(true);
      } else {
        tapTimestampsRef.current = recent;
      }
    }

    document.addEventListener('click', handleDocumentClick);
    return () => document.removeEventListener('click', handleDocumentClick);
  }, [passwordOpen, adminOpen]);

  // Subscribe to current IST month for today's live board
  useEffect(() => {
    setLoadingToday(true);
    const unsub = subscribeMonthResults(
      ist.monthStr,
      (items) => {
        setTodayMonthResults(items);
        setLoadingToday(false);
        setDbError(null);
      },
      (err) => {
        setDbError(err.message);
        setLoadingToday(false);
      }
    );
    return () => unsub();
  }, [ist.monthStr]);

  // Subscribe to selected month for the monthly historical chart
  useEffect(() => {
    if (selectedMonth === ist.monthStr) {
      setChartMonthResults(todayMonthResults);
      setLoadingChart(loadingToday);
      return;
    }
    setLoadingChart(true);
    const unsub = subscribeMonthResults(
      selectedMonth,
      (items) => {
        setChartMonthResults(items);
        setLoadingChart(false);
      },
      (err) => {
        setDbError(err.message);
        setLoadingChart(false);
      }
    );
    return () => unsub();
  }, [selectedMonth, ist.monthStr, todayMonthResults, loadingToday]);

  const todayDocsMap = useMemo(() => {
    const map: Record<string, BazaarResultDoc> = {};
    for (const item of todayMonthResults) {
      if (item.date === ist.dateStr) {
        map[item.bazaarId] = item;
      }
    }
    return map;
  }, [todayMonthResults, ist.dateStr]);

  // Resolve today's effective live numbers (respecting release schedule)
  const effectiveTodayMap = useMemo(() => {
    const map: Record<string, string> = {};
    for (const bazaar of BAZAARS) {
      const { hasPassedToday } = getSecondsUntilNextDraw(bazaar, ist);
      if (hasPassedToday) {
        const docItem = todayDocsMap[bazaar.id];
        map[bazaar.id] =
          docItem?.number ?? getAutoNumberForSlot(ist.dateStr, bazaar.id);
      }
    }
    return map;
  }, [todayDocsMap, ist]);

  // Persist auto-generated numbers to Firestore once today's release time has passed
  useEffect(() => {
    if (loadingToday) return;
    for (const bazaar of BAZAARS) {
      const { hasPassedToday } = getSecondsUntilNextDraw(bazaar, ist);
      if (!hasPassedToday) continue;
      if (todayDocsMap[bazaar.id]) continue;

      const key = `${ist.dateStr}_${bazaar.id}`;
      if (syncedAutoSlotsRef.current.has(key)) continue;
      syncedAutoSlotsRef.current.add(key);

      const autoNum = getAutoNumberForSlot(ist.dateStr, bazaar.id);
      void ensureAutoResult(ist.dateStr, bazaar.id, autoNum);
    }
  }, [loadingToday, todayDocsMap, ist]);

  return (
    <div className="min-h-screen flex flex-col bg-white text-neutral-950">
      <Header />

      <main className="flex-1">
        {dbError && (
          <div className="bg-neutral-950 text-yellow-400 border-b border-neutral-800 px-4 py-2.5 text-center text-xs sm:text-sm font-medium">
            डेटाबेस से जुड़ने में समस्या आई। कृपया पृष्ठ रिफ्रेश करें।
          </div>
        )}

        <CountdownHero ist={ist} effectiveTodayMap={effectiveTodayMap} />

        <LiveBazaarGrid
          ist={ist}
          effectiveTodayMap={effectiveTodayMap}
          loading={loadingToday}
        />

        <MonthlyChart
          selectedMonth={selectedMonth}
          currentMonth={ist.monthStr}
          todayDateStr={ist.dateStr}
          effectiveTodayMap={effectiveTodayMap}
          onChangeMonth={setSelectedMonth}
          monthResults={
            selectedMonth === ist.monthStr
              ? todayMonthResults
              : chartMonthResults
          }
          loading={
            selectedMonth === ist.monthStr ? loadingToday : loadingChart
          }
        />
      </main>

      <footer className="bg-neutral-950 text-neutral-400 border-t border-neutral-800 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 text-xs sm:text-sm">
          <span>बाज़ार लाइव रिजल्ट · सभी समय भारतीय मानक समय (IST) अनुसार</span>
        </div>
      </footer>

      <PasswordModal
        open={passwordOpen}
        onClose={() => setPasswordOpen(false)}
        onSuccess={() => {
          setPasswordOpen(false);
          setAdminOpen(true);
        }}
      />

      <AdminDrawer
        open={adminOpen}
        onClose={() => setAdminOpen(false)}
        ist={ist}
      />
    </div>
  );
}
