import { useEffect, useState } from 'react';
import { RotateCcw, X } from 'lucide-react';
import {
  BAZAARS,
  getAutoNumberForSlot,
  isSlotReleased,
  normalizeBazaarNumber,
  type IstParts,
} from '../data/bazaars';
import {
  deleteBazaarResult,
  publishBazaarResult,
  subscribeMonthResults,
  type BazaarResultDoc,
} from '../services/resultsService';

interface AdminDrawerProps {
  open: boolean;
  onClose: () => void;
  ist: IstParts;
}

export function AdminDrawer({ open, onClose, ist }: AdminDrawerProps) {
  const [selectedDate, setSelectedDate] = useState(ist.dateStr);
  const [dateResults, setDateResults] = useState<Record<string, BazaarResultDoc>>({});
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [savingAll, setSavingAll] = useState(false);
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  useEffect(() => {
    if (!open) return;
    const monthStr = selectedDate.slice(0, 7);
    const unsub = subscribeMonthResults(
      monthStr,
      (items) => {
        const forDate: Record<string, BazaarResultDoc> = {};
        for (const item of items) {
          if (item.date === selectedDate) {
            forDate[item.bazaarId] = item;
          }
        }
        const nextInputs: Record<string, string> = {};
        for (const b of BAZAARS) {
          const docItem = forDate[b.id];
          nextInputs[b.id] =
            docItem?.number ?? getAutoNumberForSlot(selectedDate, b.id);
        }
        setDateResults(forDate);
        setInputs(nextInputs);
      },
      (err) => {
        setFeedback({ type: 'error', message: err.message });
      }
    );
    return () => unsub();
  }, [open, selectedDate]);

  if (!open) return null;

  async function handleSaveSingle(bazaarId: string) {
    const normalized = normalizeBazaarNumber(inputs[bazaarId] ?? '');
    if (!normalized) {
      setFeedback({
        type: 'error',
        message: 'कृपया 01 से 100 के बीच का नंबर दर्ज करें।',
      });
      return;
    }
    setFeedback(null);
    setSavingId(bazaarId);
    try {
      await publishBazaarResult(selectedDate, bazaarId, normalized, 'admin');
      const bazaarName =
        BAZAARS.find((b) => b.id === bazaarId)?.name ?? bazaarId;
      setFeedback({
        type: 'success',
        message: `${bazaarName} (${selectedDate}) का नंबर ${normalized} सेट हो गया।`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message:
          err instanceof Error ? err.message : 'नंबर सेव करने में त्रुटि हुई।',
      });
    } finally {
      setSavingId(null);
    }
  }

  async function handleSaveAll() {
    const changed = BAZAARS.filter((b) => {
      const normalized = normalizeBazaarNumber(inputs[b.id] ?? '');
      if (!normalized) return false;
      const existing = dateResults[b.id];
      const currentEffective =
        existing?.number ?? getAutoNumberForSlot(selectedDate, b.id);
      return normalized !== currentEffective;
    });

    if (changed.length === 0) {
      setFeedback({
        type: 'error',
        message: 'सेव करने के लिए कोई बदला हुआ नंबर नहीं है।',
      });
      return;
    }

    for (const b of BAZAARS) {
      if (!normalizeBazaarNumber(inputs[b.id] ?? '')) {
        setFeedback({
          type: 'error',
          message: `${b.name} के लिए 01 से 100 के बीच सही नंबर दर्ज करें।`,
        });
        return;
      }
    }

    setFeedback(null);
    setSavingAll(true);
    try {
      for (const b of changed) {
        const normalized = normalizeBazaarNumber(inputs[b.id] ?? '')!;
        await publishBazaarResult(selectedDate, b.id, normalized, 'admin');
      }
      setFeedback({
        type: 'success',
        message: `${changed.length} बाज़ार के नंबर सफलतापूर्वक सेट हो गए।`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message:
          err instanceof Error ? err.message : 'बदलाव सेव करने में त्रुटि हुई।',
      });
    } finally {
      setSavingAll(false);
    }
  }

  async function handleResetToAuto(bazaarId: string) {
    setFeedback(null);
    setSavingId(bazaarId);
    try {
      await deleteBazaarResult(selectedDate, bazaarId);
      const autoNum = getAutoNumberForSlot(selectedDate, bazaarId);
      setInputs((prev) => ({ ...prev, [bazaarId]: autoNum }));
      const bazaarName =
        BAZAARS.find((b) => b.id === bazaarId)?.name ?? bazaarId;
      setFeedback({
        type: 'success',
        message: `${bazaarName} अब ऑटो नंबर (${autoNum}) पर सेट है।`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message:
          err instanceof Error ? err.message : 'रीसेट करने में त्रुटि हुई।',
      });
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-label="Admin परिणाम प्रबंधन"
    >
      <div className="w-full max-w-xl bg-white text-neutral-950 h-full flex flex-col border-l border-neutral-300">
        <div className="bg-neutral-950 text-white px-5 py-4 flex items-center justify-between border-b border-neutral-800">
          <div>
            <h2 className="text-lg font-extrabold">Admin रिजल्ट पैनल</h2>
            <p className="text-xs text-neutral-400">
              ऑटो आने वाले नंबर देखें और आवश्यकतानुसार बदलें (01–100)
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="बंद करें"
            className="p-2 text-neutral-300 hover:text-yellow-400 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {feedback && (
            <div
              className={`p-3 rounded-md border text-sm font-medium ${
                feedback.type === 'success'
                  ? 'bg-yellow-50 border-yellow-400 text-neutral-950'
                  : 'bg-neutral-950 border-neutral-950 text-yellow-400'
              }`}
            >
              {feedback.message}
            </div>
          )}

          <div className="flex flex-wrap items-end justify-between gap-4 pb-3 border-b border-neutral-200">
            <div>
              <label
                htmlFor="admin-date-picker"
                className="block text-xs font-bold text-neutral-700 mb-1"
              >
                तारीख चुनें
              </label>
              <input
                id="admin-date-picker"
                type="date"
                value={selectedDate}
                onChange={(e) => {
                  if (e.target.value) setSelectedDate(e.target.value);
                }}
                className="px-3 py-2 border border-neutral-300 rounded-md font-mono text-sm text-neutral-950 bg-white focus:outline-2 focus:outline-yellow-400"
              />
            </div>

            <button
              type="button"
              disabled={savingAll}
              onClick={handleSaveAll}
              className="px-4 py-2 bg-neutral-950 hover:bg-neutral-800 text-yellow-400 text-sm font-bold rounded-md transition-colors cursor-pointer disabled:opacity-50"
            >
              {savingAll ? 'सेव हो रहा है...' : 'सभी बदलाव सेव करें'}
            </button>
          </div>

          <p className="text-xs text-neutral-600">
            यदि आप कोई नंबर नहीं बदलते हैं, तो हर बाज़ार के निर्धारित समय पर नीचे दिखाया गया <strong>ऑटो नंबर</strong> अपने-आप वेबसाइट पर जारी हो जाएगा।
          </p>

          <div className="divide-y divide-neutral-200 border border-neutral-200 rounded-lg">
            {BAZAARS.map((bazaar) => {
              const existing = dateResults[bazaar.id];
              const autoNum = getAutoNumberForSlot(selectedDate, bazaar.id);
              const isAdminSet = existing?.source === 'admin';
              const released = isSlotReleased(selectedDate, bazaar, ist);
              const val = inputs[bazaar.id] ?? autoNum;
              const isSaving = savingId === bazaar.id;

              return (
                <div
                  key={bazaar.id}
                  className="p-3.5 flex flex-wrap items-center justify-between gap-3"
                >
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-neutral-950">
                        {bazaar.name}
                      </span>
                      <span className="text-xs font-mono text-neutral-500">
                        · {bazaar.displayTime}
                      </span>
                    </div>
                    <div className="text-xs text-neutral-600 flex flex-wrap items-center gap-1.5">
                      <span>
                        {isAdminSet
                          ? 'Admin द्वारा सेट'
                          : `ऑटो नंबर (${autoNum})`}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {released ? 'लाइव हो चुका' : 'समय पर लाइव होगा'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={3}
                      aria-label={`${bazaar.name} नंबर`}
                      value={val}
                      onChange={(e) => {
                        const digits = e.target.value.replace(/[^0-9]/g, '');
                        setInputs((prev) => ({
                          ...prev,
                          [bazaar.id]: digits,
                        }));
                      }}
                      className="w-16 h-10 text-center font-mono tabular-nums text-lg font-extrabold border border-neutral-300 rounded-md focus:outline-2 focus:outline-yellow-400 bg-white text-neutral-950"
                    />

                    <button
                      type="button"
                      disabled={isSaving || savingAll}
                      onClick={() => handleSaveSingle(bazaar.id)}
                      className="px-3 h-10 bg-yellow-400 hover:bg-yellow-300 text-neutral-950 text-xs font-bold rounded-md transition-colors cursor-pointer disabled:opacity-50"
                    >
                      {isSaving ? '...' : 'सेव'}
                    </button>

                    {isAdminSet && (
                      <button
                        type="button"
                        disabled={isSaving || savingAll}
                        onClick={() => handleResetToAuto(bazaar.id)}
                        title="ऑटो नंबर पर वापस सेट करें"
                        aria-label={`${bazaar.name} ऑटो पर वापस करें`}
                        className="p-2.5 h-10 border border-neutral-200 hover:border-neutral-950 text-neutral-700 hover:text-neutral-950 rounded-md transition-colors cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
