import {
  BAZAARS,
  formatCountdownHMS,
  formatDateHindi,
  formatIstClock,
  getSecondsUntilNextDraw,
  type Bazaar,
  type IstParts,
} from '../data/bazaars';

interface CountdownHeroProps {
  ist: IstParts;
  effectiveTodayMap: Record<string, string>;
}

export function CountdownHero({ ist, effectiveTodayMap }: CountdownHeroProps) {
  let nextBazaar: Bazaar = BAZAARS[0];
  let minSeconds = Number.MAX_SAFE_INTEGER;

  for (const bazaar of BAZAARS) {
    const { secondsRemaining } = getSecondsUntilNextDraw(bazaar, ist);
    if (secondsRemaining < minSeconds) {
      minSeconds = secondsRemaining;
      nextBazaar = bazaar;
    }
  }

  const countdown = formatCountdownHMS(minSeconds);

  const releasedToday = BAZAARS.filter((b) => Boolean(effectiveTodayMap[b.id]));
  const latestReleased =
    releasedToday.length > 0 ? releasedToday[releasedToday.length - 1] : null;
  const latestNumber = latestReleased
    ? effectiveTodayMap[latestReleased.id]
    : null;

  return (
    <section
      id="top"
      className="bg-neutral-950 text-white border-b-4 border-yellow-400"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm text-neutral-300 pb-6 border-b border-neutral-800">
          <div className="flex flex-wrap items-center gap-2">
            <span>{formatDateHindi(ist.dateStr)}</span>
            <span aria-hidden="true">·</span>
            <span>सभी 12 बाज़ार लाइव समय सारणी</span>
          </div>
          <div className="font-mono tabular-nums text-yellow-400 font-semibold">
            अभी का समय: {formatIstClock(ist)} IST
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-7">
          <div className="lg:col-span-7 space-y-3">
            <p className="text-sm font-semibold text-yellow-400">
              अगला आने वाला रिजल्ट (उल्टी गिनती)
            </p>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
              {nextBazaar.name}
            </h1>
            <div className="flex flex-wrap items-center gap-3 text-sm sm:text-base text-neutral-300 pt-1">
              <span>
                निर्धारित समय:{' '}
                <strong className="text-white font-mono tabular-nums">
                  {nextBazaar.displayTime}
                </strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                शेष समय:{' '}
                <strong className="text-yellow-400 font-mono tabular-nums">
                  {Number(countdown.hours)} घंटे {Number(countdown.minutes)} मिनट{' '}
                  {Number(countdown.seconds)} सेकंड
                </strong>
              </span>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 sm:p-6">
              <div className="text-xs font-medium text-neutral-400 mb-3">
                रिजल्ट जारी होने में शेष समय (HH : MM : SS)
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-black border border-neutral-800 rounded-md py-3 px-2">
                  <div className="font-mono tabular-nums text-3xl sm:text-4xl font-extrabold text-yellow-400">
                    {countdown.hours}
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">घंटे</div>
                </div>
                <div className="bg-black border border-neutral-800 rounded-md py-3 px-2">
                  <div className="font-mono tabular-nums text-3xl sm:text-4xl font-extrabold text-yellow-400">
                    {countdown.minutes}
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">मिनट</div>
                </div>
                <div className="bg-black border border-neutral-800 rounded-md py-3 px-2">
                  <div className="font-mono tabular-nums text-3xl sm:text-4xl font-extrabold text-white">
                    {countdown.seconds}
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">सेकंड</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {latestReleased && latestNumber && (
          <div className="mt-7 pt-5 border-t border-neutral-800 flex flex-wrap items-center justify-between gap-4 text-sm">
            <div className="flex items-center gap-3">
              <span className="text-neutral-400">आज का ताज़ा घोषित रिजल्ट:</span>
              <span className="font-bold text-white">{latestReleased.name}</span>
              <span className="text-neutral-500" aria-hidden="true">
                ·
              </span>
              <span className="font-mono text-neutral-300">
                {latestReleased.displayTime}
              </span>
            </div>
            <div className="font-mono tabular-nums text-lg font-extrabold text-neutral-950 bg-yellow-400 px-3.5 py-1 rounded">
              {latestNumber}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
