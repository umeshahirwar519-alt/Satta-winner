export function Header() {
  return (
    <header className="sticky top-0 z-30 bg-neutral-950 text-white border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        <a
          href="#top"
          className="text-lg sm:text-xl font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2.5 focus-visible:outline-2 focus-visible:outline-yellow-400"
        >
          <span className="inline-block w-3 h-3 bg-yellow-400" aria-hidden="true" />
          <span>बाज़ार लाइव रिजल्ट</span>
        </a>

        <nav className="flex items-center gap-5 sm:gap-6 text-sm font-medium text-neutral-300">
          <a
            href="#today-results"
            className="hover:text-yellow-400 transition-colors whitespace-nowrap shrink-0 py-1"
          >
            आज के रिजल्ट
          </a>
          <a
            href="#monthly-chart"
            className="hover:text-yellow-400 transition-colors whitespace-nowrap shrink-0 py-1"
          >
            मासिक चार्ट
          </a>
        </nav>
      </div>
    </header>
  );
}
