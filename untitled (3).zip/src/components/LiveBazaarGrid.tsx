import {
  BAZAARS,
  formatCountdownHMS,
  getSecondsUntilNextDraw,
  type IstParts,
} from '../data/bazaars';

interface LiveBazaarGridProps {
  ist: IstParts;
  effectiveTodayMap: Record<string, string>;
  loading: boolean;
}

export function LiveBazaarGrid({
  ist,
  effectiveTodayMap,
  loading,
}: LiveBazaarGridProps) {
  let nextBazaarId = BAZAARS[0].id;
  let minSec = Number.MAX_SAFE_INTEGER;
  for (const bazaar of BAZAARS) {
    const { secondsRemaining } = getSecondsUntilNextDraw(bazaar, ist);
    if (secondsRemaining < minSec) {
      minSec = secondsRemaining;
      nextBazaarId = bazaar.id;
    }
  }

  const releasedCount = BAZAARS.filter((b) =>
    Boolean(effectiveTodayMap[b.id])
  ).length;

  return (
    <section
      id="today-results"
      className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-12"
    >
      <div className="flex flex-wrap items-end justify-between gap-4 pb-6 border-b border-neutral-200">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-950 tracking-tight">
            आज के बाज़ार रिजल्ट
          </h2>
          <p className="text-sm text-neutral-600 mt-1">
            प्रत्येक बाज़ार का निर्धारित समय, लाइव नंबर और सेकंड में उल्टी गिनती
          </p>
        </div>
        <div className="text-sm font-semibold text-neutral-950 font-mono tabular-nums">
          आज घोषित: {releasedCount} / {BAZAARS.length}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pt-6">
        {BAZAARS.map((bazaar) => {
          const releasedNumber = effectiveTodayMap[bazaar.id];
          const { secondsRemaining, hasPassedToday } = getSecondsUntilNextDraw(
            bazaar,
            ist
          );
          const countdown = formatCountdownHMS(secondsRemaining);
          const isNext = bazaar.id === nextBazaarId;

          let statusLabel = 'आने वाला है';
          if (releasedNumber) {
            statusLabel = 'रिजल्ट घोषित';
          } else if (isNext) {
            statusLabel = 'अगला रिजल्ट';
          }

          return (
            <article
              key={bazaar.id}
              className={`rounded-lg p-5 flex flex-col justify-between gap-4 transition-colors ${
                isNext && !releasedNumber
                  ? 'bg-yellow-50 border-2 border-yellow-400'
                  : 'bg-white border border-neutral-200 hover:border-neutral-400'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold text-neutral-950 leading-snug">
                    {bazaar.name}
                  </h3>
                  <p className="text-xs text-neutral-600 mt-0.5">{statusLabel}</p>
                </div>
                <span className="font-mono tabular-nums text-xs font-bold text-neutral-950 bg-neutral-100 px-2.5 py-1 rounded shrink-0">
                  {bazaar.displayTime}
                </span>
              </div>

              <div className="flex items-center justify-between gap-4 py-1">
                <div>
                  <div className="text-xs text-neutral-500">आज का नंबर</div>
                  {loading && hasPassedToday ? (
                    <div className="h-10 w-16 bg-neutral-100 rounded mt-1" />
                  ) : releasedNumber ? (
                    <div className="mt-1 inline-flex items-center justify-center min-w-[3.75rem] px-3 py-1.5 rounded bg-neutral-950 text-yellow-400 font-mono tabular-nums text-2xl font-extrabold">
                      {releasedNumber}
                    </div>
                  ) : (
                    <div className="mt-1 inline-flex items-center justify-center min-w-[3.75rem] px-3 py-1.5 rounded bg-neutral-100 text-neutral-400 font-mono tabular-nums text-2xl font-bold">
                      --
                    </div>
                  )}
                </div>

                <div className="text-right">
                  <div className="text-xs text-neutral-500">
                    {hasPassedToday ? 'अगला ड्रॉ' : 'उल्टी गिनती'}
                  </div>
                  <div
                    className={`mt-1 font-mono tabular-nums text-lg font-extrabold ${
                      isNext && !releasedNumber
                        ? 'text-neutral-950'
                        : 'text-neutral-800'
                    }`}
                  >
                    {countdown.formatted}
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
