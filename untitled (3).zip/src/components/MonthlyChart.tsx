import { ChevronLeft, ChevronRight } from 'lucide-react';
import {
  BAZAARS,
  formatMonthHindi,
  getAutoNumberForSlot,
  getDaysInMonth,
  shiftMonth,
} from '../data/bazaars';
import type { BazaarResultDoc } from '../services/resultsService';

interface MonthlyChartProps {
  selectedMonth: string;
  currentMonth: string;
  todayDateStr: string;
  effectiveTodayMap: Record<string, string>;
  onChangeMonth: (month: string) => void;
  monthResults: BazaarResultDoc[];
  loading: boolean;
}

export function MonthlyChart({
  selectedMonth,
  currentMonth,
  todayDateStr,
  effectiveTodayMap,
  onChangeMonth,
  monthResults,
  loading,
}: MonthlyChartProps) {
  const gridMap: Record<string, Record<string, string>> = {};
  for (const item of monthResults) {
    if (!gridMap[item.date]) {
      gridMap[item.date] = {};
    }
    gridMap[item.date][item.bazaarId] = item.number;
  }

  const allMonthDays = getDaysInMonth(selectedMonth);
  const visibleDays =
    selectedMonth === currentMonth
      ? allMonthDays.filter((d) => d <= todayDateStr)
      : allMonthDays;

  const orderedDays = [...visibleDays].reverse();
  const isCurrentMonth = selectedMonth === currentMonth;
  const canGoNext = selectedMonth < currentMonth;

  return (
    <section
      id="monthly-chart"
      className="bg-neutral-50 border-t border-neutral-200 py-10 sm:py-12"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-950 tracking-tight">
              मासिक रिजल्ट चार्ट
            </h2>
            <p className="text-sm text-neutral-600 mt-1">
              पिछले दिनों और महीनों के सभी बाज़ार परिणाम ({formatMonthHindi(selectedMonth)})
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!isCurrentMonth && (
              <button
                type="button"
                onClick={() => onChangeMonth(currentMonth)}
                className="px-3 py-2 text-xs sm:text-sm font-semibold text-neutral-950 bg-yellow-400 hover:bg-yellow-300 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                मौजूदा महीना
              </button>
            )}

            <div className="inline-flex items-center bg-white border border-neutral-300 rounded-md">
              <button
                type="button"
                onClick={() => onChangeMonth(shiftMonth(selectedMonth, -1))}
                aria-label="पिछला महीना"
                className="p-2 text-neutral-800 hover:bg-neutral-100 rounded-l-md transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-3 sm:px-4 py-1.5 text-sm font-bold text-neutral-950 min-w-[8.5rem] text-center whitespace-nowrap">
                {formatMonthHindi(selectedMonth)}
              </span>
              <button
                type="button"
                disabled={!canGoNext}
                onClick={() => onChangeMonth(shiftMonth(selectedMonth, 1))}
                aria-label="अगला महीना"
                className="p-2 text-neutral-800 hover:bg-neutral-100 disabled:opacity-30 disabled:pointer-events-none rounded-r-md transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white border border-neutral-300 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-neutral-950 text-white border-b border-neutral-800">
                  <th className="sticky left-0 z-10 bg-neutral-950 px-3 sm:px-4 py-3 text-xs font-bold whitespace-nowrap border-r border-neutral-800 min-w-[5.5rem]">
                    तारीख
                  </th>
                  {BAZAARS.map((bazaar) => (
                    <th
                      key={bazaar.id}
                      className="px-3 py-3 text-center whitespace-nowrap border-r border-neutral-800 last:border-r-0 min-w-[5.75rem]"
                    >
                      <div className="text-xs font-bold text-white">
                        {bazaar.shortName}
                      </div>
                      <div className="text-[11px] font-mono text-yellow-400 mt-0.5">
                        {bazaar.displayTime}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 text-sm">
                {loading ? (
                  Array.from({ length: 6 }).map((_, idx) => (
                    <tr key={idx} className="bg-white">
                      <td className="px-4 py-3 border-r border-neutral-200">
                        <div className="h-4 w-12 bg-neutral-100 rounded" />
                      </td>
                      {BAZAARS.map((b) => (
                        <td
                          key={b.id}
                          className="px-3 py-3 text-center border-r border-neutral-200 last:border-r-0"
                        >
                          <div className="h-4 w-7 bg-neutral-100 rounded mx-auto" />
                        </td>
                      ))}
                    </tr>
                  ))
                ) : orderedDays.length === 0 ? (
                  <tr>
                    <td
                      colSpan={BAZAARS.length + 1}
                      className="px-6 py-10 text-center text-neutral-500 text-sm"
                    >
                      इस महीने के लिए अभी कोई परिणाम उपलब्ध नहीं है।
                    </td>
                  </tr>
                ) : (
                  orderedDays.map((dateStr) => {
                    const isToday = dateStr === todayDateStr;
                    const isPastDay = dateStr < todayDateStr;
                    const dayNum = dateStr.slice(8, 10);
                    const rowData = gridMap[dateStr] ?? {};

                    return (
                      <tr
                        key={dateStr}
                        className={
                          isToday
                            ? 'bg-yellow-100/70 hover:bg-yellow-100 transition-colors'
                            : 'bg-white hover:bg-neutral-50 transition-colors'
                        }
                      >
                        <td
                          className={`sticky left-0 z-10 px-3 sm:px-4 py-2.5 font-mono tabular-nums text-xs sm:text-sm font-bold border-r border-neutral-200 whitespace-nowrap ${
                            isToday
                              ? 'bg-yellow-200 text-neutral-950'
                              : 'bg-neutral-50 text-neutral-900'
                          }`}
                        >
                          {dayNum}-{dateStr.slice(5, 7)}
                          {isToday && (
                            <span className="ml-1.5 text-[11px] font-sans font-bold text-neutral-950">
                              (आज)
                            </span>
                          )}
                        </td>
                        {BAZAARS.map((bazaar) => {
                          let val: string | undefined;
                          if (isToday) {
                            val = effectiveTodayMap[bazaar.id];
                          } else if (isPastDay) {
                            val =
                              rowData[bazaar.id] ??
                              getAutoNumberForSlot(dateStr, bazaar.id);
                          }

                          return (
                            <td
                              key={bazaar.id}
                              className="px-3 py-2.5 text-center font-mono tabular-nums border-r border-neutral-200 last:border-r-0"
                            >
                              {val ? (
                                <span className="inline-block font-extrabold text-neutral-950">
                                  {val}
                                </span>
                              ) : (
                                <span className="text-neutral-300">--</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
