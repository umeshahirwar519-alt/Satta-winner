import { useState, type FormEvent } from 'react';
import { X } from 'lucide-react';

interface PasswordModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function PasswordModal({ open, onClose, onSuccess }: PasswordModalProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (password === 'Sir2012') {
      setPassword('');
      setError(null);
      onSuccess();
    } else {
      setError('गलत पासवर्ड। कृपया सही पासवर्ड दर्ज करें।');
    }
  }

  function handleClose() {
    setPassword('');
    setError(null);
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Admin पासवर्ड सत्यापन"
    >
      <div className="w-full max-w-sm bg-white text-neutral-950 border-2 border-neutral-950 rounded-lg overflow-hidden">
        <div className="bg-neutral-950 text-white px-5 py-3.5 flex items-center justify-between">
          <h2 className="text-base font-extrabold">Admin सत्यापन</h2>
          <button
            type="button"
            onClick={handleClose}
            aria-label="बंद करें"
            className="p-1 text-neutral-300 hover:text-yellow-400 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label
              htmlFor="admin-secret-password"
              className="block text-xs font-bold text-neutral-700 mb-1.5"
            >
              पासवर्ड दर्ज करें
            </label>
            <input
              id="admin-secret-password"
              type="password"
              autoFocus
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (error) setError(null);
              }}
              placeholder="पासवर्ड लिखें"
              className="w-full px-3.5 py-2.5 border border-neutral-300 rounded-md text-sm font-mono text-neutral-950 bg-white focus:outline-2 focus:outline-yellow-400"
            />
          </div>

          {error && (
            <p className="text-xs font-semibold text-neutral-950 bg-yellow-100 border border-yellow-400 px-3 py-2 rounded">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2 text-sm font-semibold text-neutral-700 hover:text-neutral-950 border border-neutral-300 rounded-md cursor-pointer"
            >
              रद्द करें
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-bold text-neutral-950 bg-yellow-400 hover:bg-yellow-300 rounded-md transition-colors cursor-pointer"
            >
              खोलें
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
