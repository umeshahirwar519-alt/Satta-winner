export interface Bazaar {
  id: string;
  name: string;
  shortName: string;
  displayTime: string;
  hour: number;
  minute: number;
}

export const BAZAARS: Bazaar[] = [
  { id: 'shri-nagar', name: 'श्री नगर', shortName: 'श्री नगर', displayTime: '1:25 PM', hour: 13, minute: 25 },
  { id: 'sardar-shahar', name: 'सरदार शहर', shortName: 'सरदार शहर', displayTime: '2:25 PM', hour: 14, minute: 25 },
  { id: 'delhi-bazaar', name: 'दिल्ली बाज़ार', shortName: 'दिल्ली बाज़ार', displayTime: '3:00 PM', hour: 15, minute: 0 },
  { id: 'gazipur-city', name: 'गाजीपुर city', shortName: 'गाजीपुर', displayTime: '3:50 PM', hour: 15, minute: 50 },
  { id: 'shri-ganesh', name: 'श्री गणेश', shortName: 'श्री गणेश', displayTime: '4:30 PM', hour: 16, minute: 30 },
  { id: 'thanesar', name: 'थानेसर', shortName: 'थानेसर', displayTime: '5:20 PM', hour: 17, minute: 20 },
  { id: 'faridabad', name: 'फरीदाबाद', shortName: 'फरीदाबाद', displayTime: '5:50 PM', hour: 17, minute: 50 },
  { id: 'surat-bazaar', name: 'सूरत बाज़ार', shortName: 'सूरत बाज़ार', displayTime: '6:00 PM', hour: 18, minute: 0 },
  { id: 'ghaziabad', name: 'गाजियाबाद', shortName: 'गाजियाबाद', displayTime: '9:30 PM', hour: 21, minute: 30 },
  { id: 'jaunpur', name: 'जौनपुर', shortName: 'जौनपुर', displayTime: '10:20 PM', hour: 22, minute: 20 },
  { id: 'gali', name: 'गली', shortName: 'गली', displayTime: '11:30 PM', hour: 23, minute: 30 },
  { id: 'disawar', name: 'दिसावर', shortName: 'दिसावर', displayTime: '2:30 AM', hour: 2, minute: 30 },
];

export const VALID_BAZAAR_IDS = new Set(BAZAARS.map((b) => b.id));

export interface IstParts {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
  dateStr: string;
  monthStr: string;
}

export function getIstParts(date: Date = new Date()): IstParts {
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(date);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? '00';
  const year = Number(get('year'));
  const month = Number(get('month'));
  const day = Number(get('day'));
  let hour = Number(get('hour'));
  if (hour === 24) hour = 0;
  const minute = Number(get('minute'));
  const second = Number(get('second'));
  const dateStr = `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const monthStr = `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}`;
  return { year, month, day, hour, minute, second, dateStr, monthStr };
}

export function formatIstClock(ist: IstParts): string {
  const period = ist.hour >= 12 ? 'PM' : 'AM';
  const h12 = ist.hour % 12 === 0 ? 12 : ist.hour % 12;
  return `${String(h12).padStart(2, '0')}:${String(ist.minute).padStart(2, '0')}:${String(ist.second).padStart(2, '0')} ${period}`;
}

export function getSecondsUntilNextDraw(bazaar: Bazaar, ist: IstParts): {
  secondsRemaining: number;
  hasPassedToday: boolean;
} {
  const nowSec = ist.hour * 3600 + ist.minute * 60 + ist.second;
  const targetSec = bazaar.hour * 3600 + bazaar.minute * 60;
  if (targetSec > nowSec) {
    return {
      secondsRemaining: targetSec - nowSec,
      hasPassedToday: false,
    };
  }
  return {
    secondsRemaining: 86400 - nowSec + targetSec,
    hasPassedToday: true,
  };
}

export function isSlotReleased(
  dateStr: string,
  bazaar: Bazaar,
  ist: IstParts
): boolean {
  if (dateStr < ist.dateStr) return true;
  if (dateStr > ist.dateStr) return false;
  return getSecondsUntilNextDraw(bazaar, ist).hasPassedToday;
}

/**
 * Deterministic 1..100 number generator seeded by (dateStr, bazaarId).
 * Returns "01".."99" or "100". Consistent across all visitors & refreshes.
 */
export function getAutoNumberForSlot(dateStr: string, bazaarId: string): string {
  const seedKey = `${dateStr}_${bazaarId}_auto_v1`;
  let h = 2166136261;
  for (let i = 0; i < seedKey.length; i++) {
    h ^= seedKey.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  // Mulberry32 mixing step
  let t = (h >>> 0) + 0x6d2b79f5;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  const rand = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  const num = Math.floor(rand * 100) + 1; // 1 to 100
  return num === 100 ? '100' : String(num).padStart(2, '0');
}

export function normalizeBazaarNumber(raw: string): string | null {
  const trimmed = raw.trim();
  if (!/^[0-9]{1,3}$/.test(trimmed)) return null;
  const n = Number(trimmed);
  if (n < 0 || n > 100) return null;
  if (n === 100) return '100';
  return String(n).padStart(2, '0');
}

export function formatCountdownHMS(totalSeconds: number): {
  hours: string;
  minutes: string;
  seconds: string;
  formatted: string;
} {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  const hours = String(h).padStart(2, '0');
  const minutes = String(m).padStart(2, '0');
  const seconds = String(s).padStart(2, '0');
  return {
    hours,
    minutes,
    seconds,
    formatted: `${hours}:${minutes}:${seconds}`,
  };
}

const HINDI_MONTHS = [
  'जनवरी',
  'फ़रवरी',
  'मार्च',
  'अप्रैल',
  'मई',
  'जून',
  'जुलाई',
  'अगस्त',
  'सितंबर',
  'अक्टूबर',
  'नवंबर',
  'दिसंबर',
];

export function formatMonthHindi(monthStr: string): string {
  const [yStr, mStr] = monthStr.split('-');
  const mIdx = Number(mStr) - 1;
  return `${HINDI_MONTHS[mIdx] ?? mStr} ${yStr}`;
}

export function formatDateHindi(dateStr: string): string {
  const [yStr, mStr, dStr] = dateStr.split('-');
  const mIdx = Number(mStr) - 1;
  return `${Number(dStr)} ${HINDI_MONTHS[mIdx] ?? mStr} ${yStr}`;
}

export function getDaysInMonth(monthStr: string): string[] {
  const [yStr, mStr] = monthStr.split('-');
  const year = Number(yStr);
  const month = Number(mStr);
  const totalDays = new Date(year, month, 0).getDate();
  const days: string[] = [];
  for (let d = 1; d <= totalDays; d++) {
    days.push(`${monthStr}-${String(d).padStart(2, '0')}`);
  }
  return days;
}

export function shiftMonth(monthStr: string, delta: number): string {
  const [yStr, mStr] = monthStr.split('-');
  const d = new Date(Number(yStr), Number(mStr) - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
