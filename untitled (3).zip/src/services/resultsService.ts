import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { normalizeBazaarNumber, VALID_BAZAAR_IDS } from '../data/bazaars';

export interface BazaarResultDoc {
  id: string;
  date: string;
  month: string;
  bazaarId: string;
  number: string;
  source: 'admin' | 'auto';
}

const DATE_REGEX = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/;

export function subscribeMonthResults(
  monthStr: string,
  onData: (results: BazaarResultDoc[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = 'results';
  const q = query(collection(db, path), where('month', '==', monthStr));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: BazaarResultDoc[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (
          typeof data.date === 'string' &&
          typeof data.month === 'string' &&
          typeof data.bazaarId === 'string' &&
          typeof data.number === 'string'
        ) {
          items.push({
            id: docSnap.id,
            date: data.date,
            month: data.month,
            bazaarId: data.bazaarId,
            number: data.number,
            source: data.source === 'auto' ? 'auto' : 'admin',
          });
        }
      });
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) {
          onError(wrapped);
        }
      }
    }
  );
}

export async function publishBazaarResult(
  dateStr: string,
  bazaarId: string,
  rawNumber: string,
  source: 'admin' | 'auto' = 'admin'
): Promise<void> {
  if (!DATE_REGEX.test(dateStr)) {
    throw new Error('तारीख का प्रारूप अमान्य है (YYYY-MM-DD)।');
  }
  if (!VALID_BAZAAR_IDS.has(bazaarId)) {
    throw new Error('अमान्य बाज़ार चुना गया है।');
  }
  const normalized = normalizeBazaarNumber(rawNumber);
  if (!normalized) {
    throw new Error('कृपया 01 से 100 के बीच का नंबर दर्ज करें।');
  }

  const monthStr = dateStr.slice(0, 7);
  const resultId = `${dateStr}_${bazaarId}`;
  const docRef = doc(db, 'results', resultId);
  const path = `results/${resultId}`;

  try {
    const existingSnap = await getDoc(docRef);
    if (existingSnap.exists()) {
      await updateDoc(docRef, {
        number: normalized,
        source,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(docRef, {
        date: dateStr,
        month: monthStr,
        bazaarId,
        number: normalized,
        source,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function ensureAutoResult(
  dateStr: string,
  bazaarId: string,
  autoNumber: string
): Promise<void> {
  const resultId = `${dateStr}_${bazaarId}`;
  const docRef = doc(db, 'results', resultId);
  try {
    const existingSnap = await getDoc(docRef);
    if (!existingSnap.exists()) {
      await setDoc(docRef, {
        date: dateStr,
        month: dateStr.slice(0, 7),
        bazaarId,
        number: autoNumber,
        source: 'auto',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch {
    // Non-blocking background persistence; deterministic UI value remains consistent
  }
}

export async function deleteBazaarResult(
  dateStr: string,
  bazaarId: string
): Promise<void> {
  const resultId = `${dateStr}_${bazaarId}`;
  const path = `results/${resultId}`;
  try {
    await deleteDoc(doc(db, 'results', resultId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
